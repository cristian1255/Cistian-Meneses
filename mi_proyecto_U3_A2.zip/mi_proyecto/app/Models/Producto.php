<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Producto extends Model
{
    use HasFactory;

    protected $fillable = [
        'nombre',
        'precio',
        'descripcion',
        'stock',
        'categoria',
        'activo'
    ];

    // CASTS: convierte tipos automáticamente
    protected $casts = [
        'precio' => 'float',
        'activo' => 'boolean',
        'stock'  => 'integer',
        'created_at' => 'datetime',
        'updated_at' => 'datetime',
    ];

    // ACCESOR: cada vez que leamos ->nombre, lo devolvemos en MAYÚSCULAS
    public function getNombreAttribute($value)
    {
        return strtoupper($value);
    }

    // MUTADOR: al guardar ->nombre lo normalizamos (Primera letra mayúscula)
    public function setNombreAttribute($value)
    {
        $this->attributes['nombre'] = ucfirst(strtolower($value));
    }

    // Ejemplo adicional: accesor para precio formateado (opcional)
    public function getPrecioFormattedAttribute()
    {
        return number_format($this->precio, 2);
    }
}
