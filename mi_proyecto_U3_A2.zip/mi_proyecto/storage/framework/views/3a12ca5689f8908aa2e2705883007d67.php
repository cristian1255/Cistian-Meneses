

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Editar producto</h1>

    <form action="<?php echo e(route('productos.update', $producto->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" value="<?php echo e($producto->nombre); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" value="<?php echo e($producto->precio); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control"><?php echo e($producto->descripcion); ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Stock</label>
            <input type="number" name="stock" value="<?php echo e($producto->stock); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <input type="text" name="categoria" value="<?php echo e($producto->categoria); ?>" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Activo</label>
            <select name="activo" class="form-select">
                <option value="1" <?php echo e($producto->activo ? 'selected' : ''); ?>>Sí</option>
                <option value="0" <?php echo e(!$producto->activo ? 'selected' : ''); ?>>No</option>
            </select>
        </div>

        <button class="btn btn-success">Actualizar</button>
        <a href="<?php echo e(route('productos.index')); ?>" class="btn btn-secondary">Regresar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\mi_proyecto\resources\views/productos/edit.blade.php ENDPATH**/ ?>