<?php

use App\Http\Controllers\ProductoController;

Route::resource('productos', ProductoController::class);
