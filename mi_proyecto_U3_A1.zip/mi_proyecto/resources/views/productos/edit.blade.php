@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="mb-4">Editar producto</h1>

    <form action="{{ route('productos.update', $producto->id) }}" method="POST">
        @csrf
        @method('PUT')

        <div class="mb-3">
            <label class="form-label">Nombre</label>
            <input type="text" name="nombre" value="{{ $producto->nombre }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Precio</label>
            <input type="number" step="0.01" name="precio" value="{{ $producto->precio }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control">{{ $producto->descripcion }}</textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Stock</label>
            <input type="number" name="stock" value="{{ $producto->stock }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Categoría</label>
            <input type="text" name="categoria" value="{{ $producto->categoria }}" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Activo</label>
            <select name="activo" class="form-select">
                <option value="1" {{ $producto->activo ? 'selected' : '' }}>Sí</option>
                <option value="0" {{ !$producto->activo ? 'selected' : '' }}>No</option>
            </select>
        </div>

        <button class="btn btn-success">Actualizar</button>
        <a href="{{ route('productos.index') }}" class="btn btn-secondary">Regresar</a>
    </form>
</div>
@endsection
