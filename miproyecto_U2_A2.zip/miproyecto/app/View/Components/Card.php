<?php

namespace App\View\Components;

use Illuminate\View\Component;

class Card extends Component
{
    public $titulo;

    public function __construct($titulo = '')
    {
        $this->titulo = $titulo;
    }

    public function render()
    {
        return view('components.card');
    }
}
