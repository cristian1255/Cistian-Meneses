<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class GanadoController extends Controller
{
    public function index()
    {
        // Datos de ejemplo que enviaremos a la vista
        $razas = [
            ['id'=>1,'nombre'=>'Holstein','descripcion'=>'Raza lechera, alta producción.','imagen'=>'https://cdn.pixabay.com/photo/2017/03/02/14/12/cow-2111103_1280.jpg'],
            ['id'=>2,'nombre'=>'Angus','descripcion'=>'Raza de carne, excelente marmoleo.','imagen'=>'https://cdn.pixabay.com/photo/2016/02/19/11/19/cow-1209022_1280.jpg'],
            ['id'=>3,'nombre'=>'Brahman','descripcion'=>'Resistente a climas cálidos.','imagen'=>'https://cdn.pixabay.com/photo/2018/03/21/21/29/cow-3243184_1280.jpg'],
        ];

        // Llamamos a la vista resources/views/componentes.blade.php
        return view('componentes', compact('razas'));
    }
}
