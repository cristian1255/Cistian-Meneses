<?php

use Illuminate\Support\Facades\Route;

Route::get('/inicio', function () {
    return view('paginas.inicio');
})->name('inicio');

Route::get('/acerca', function () {
    return view('paginas.acerca');
})->name('acerca');
