<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Práctica Componentes - Razas de Ganado</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
        body{font-family: Arial, Helvetica, sans-serif; margin:20px; background:#f4f6f8;}
        header{height:220px;background:url('https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat; display:flex;align-items:center;justify-content:center;color:#fff;font-size:28px;text-shadow:2px 2px 6px rgba(0,0,0,.6);border-radius:6px}
        .container{display:flex;gap:20px;margin-top:20px}
        .left{width:260px;background:#2c3e50;color:#fff;padding:20px;border-radius:6px}
        .right{flex:1;padding:20px}
        .raza-card{background:#fff;padding:15px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:16px}
        .raza-card img{width:100%;height:180px;object-fit:cover;border-radius:6px}
    </style>
</head>
<body>

<header>Panel de Componentes - Razas de Ganado</header>

<div class="container">
    <div class="left">
        <h3>Menú</h3>
        <ul>
            <li><a href="<?php echo e(route('componentes')); ?>" style="color:#fff;text-decoration:none">Inicio</a></li>
            <li style="margin-top:8px;color:#ddd">Razas</li>
            <li style="margin-top:8px;color:#ddd">Alimentación</li>
        </ul>
    </div>

    <div class="right">
        
        <?php if (isset($component)) { $__componentOriginal88538ab87cb05b41e7c48dce9d7aea72 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal88538ab87cb05b41e7c48dce9d7aea72 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.titulo','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('titulo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>Práctica de Componentes en Laravel <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal88538ab87cb05b41e7c48dce9d7aea72)): ?>
<?php $attributes = $__attributesOriginal88538ab87cb05b41e7c48dce9d7aea72; ?>
<?php unset($__attributesOriginal88538ab87cb05b41e7c48dce9d7aea72); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88538ab87cb05b41e7c48dce9d7aea72)): ?>
<?php $component = $__componentOriginal88538ab87cb05b41e7c48dce9d7aea72; ?>
<?php unset($__componentOriginal88538ab87cb05b41e7c48dce9d7aea72); ?>
<?php endif; ?>

        
        <?php if (isset($component)) { $__componentOriginalf5166fa323f2f22d46fefef155cbdd57 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5166fa323f2f22d46fefef155cbdd57 = $attributes; } ?>
<?php $component = App\View\Components\Alerta::resolve(['tipo' => 'success','mensaje' => 'El proyecto está funcionando correctamente.'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alerta'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alerta::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5166fa323f2f22d46fefef155cbdd57)): ?>
<?php $attributes = $__attributesOriginalf5166fa323f2f22d46fefef155cbdd57; ?>
<?php unset($__attributesOriginalf5166fa323f2f22d46fefef155cbdd57); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5166fa323f2f22d46fefef155cbdd57)): ?>
<?php $component = $__componentOriginalf5166fa323f2f22d46fefef155cbdd57; ?>
<?php unset($__componentOriginalf5166fa323f2f22d46fefef155cbdd57); ?>
<?php endif; ?>

        <h2 style="color:#27ae60;margin-top:20px">Listado de Razas</h2>

        
        <?php $__currentLoopData = $razas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $raza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if (isset($component)) { $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64 = $attributes; } ?>
<?php $component = App\View\Components\Card::resolve(['titulo' => ''.e($raza['nombre']).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Card::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <img src="<?php echo e($raza['imagen']); ?>" alt="<?php echo e($raza['nombre']); ?>" style="width:100%;height:220px;object-fit:cover;border-radius:6px;margin-bottom:10px">
                <p><?php echo e($raza['descripcion']); ?></p>

                 <?php $__env->slot('footer', null, []); ?> 
                    ID: <?php echo e($raza['id']); ?> — Fuente: Pixabay
                 <?php $__env->endSlot(); ?>
             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $attributes = $__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__attributesOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64)): ?>
<?php $component = $__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64; ?>
<?php unset($__componentOriginal740c66ff9bbfcb19a96a45ba2fa42d64); ?>
<?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
</div>

</body>
</html>
<?php /**PATH /home/cristian/servidor/miproyecto/resources/views/componentes.blade.php ENDPATH**/ ?>