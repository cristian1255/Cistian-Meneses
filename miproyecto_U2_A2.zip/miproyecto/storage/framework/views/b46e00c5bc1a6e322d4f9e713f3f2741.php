<?php $__env->startSection('titulo', 'Acerca'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 class="text-success">Acerca del Proyecto</h1>
<p>Esta página demuestra el uso de Blade con layouts y secciones.</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cristian/servidor/miproyecto/resources/views/paginas/acerca.blade.php ENDPATH**/ ?>