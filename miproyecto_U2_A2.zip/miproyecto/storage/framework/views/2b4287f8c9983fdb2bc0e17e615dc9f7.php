<?php $__env->startSection('titulo', 'Inicio'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 class="text-primary">Bienvenido a mi plantilla Laravel</h1>
<p>Esta es una vista que usa una plantilla maestra con secciones e includes.</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.plantilla', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/cristian/servidor/miproyecto/resources/views/paginas/inicio.blade.php ENDPATH**/ ?>