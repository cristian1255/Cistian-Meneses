<footer class="text-center mt-5 mb-3 text-muted">
    <hr>
    <p>© 2025 - Plantillas con Laravel | IT Tizimín</p>
</footer>
<?php /**PATH /home/cristian/servidor/miproyecto/resources/views/partials/footer.blade.php ENDPATH**/ ?>