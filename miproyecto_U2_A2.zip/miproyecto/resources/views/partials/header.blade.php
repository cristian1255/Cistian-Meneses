<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Mi Proyecto Laravel</a>

        <ul class="navbar-nav ms-auto">
            <li class="nav-item"><a href="/inicio" class="nav-link">Inicio</a></li>
            <li class="nav-item"><a href="/acerca" class="nav-link">Acerca</a></li>
        </ul>
    </div>
</nav>
