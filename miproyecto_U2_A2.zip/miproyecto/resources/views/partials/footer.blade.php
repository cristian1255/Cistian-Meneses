<footer class="text-center mt-5 mb-3 text-muted">
    <hr>
    <p>© 2025 - Plantillas con Laravel | IT Tizimín</p>
</footer>
