@extends('layouts.plantilla')

@section('titulo', 'Acerca')

@section('contenido')

<h1 class="text-success">Acerca del Proyecto</h1>
<p>Esta página demuestra el uso de Blade con layouts y secciones.</p>

@endsection
