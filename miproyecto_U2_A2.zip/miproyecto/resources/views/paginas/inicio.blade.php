@extends('layouts.plantilla')

@section('titulo', 'Inicio')

@section('contenido')

<h1 class="text-primary">Bienvenido a mi plantilla Laravel</h1>
<p>Esta es una vista que usa una plantilla maestra con secciones e includes.</p>

@endsection
