@php
    // Mapeo sencillo para estilos
    $bg = match($tipo) {
        'success' => '#e6ffed',
        'warning' => '#fff4e5',
        'danger' => '#ffe6e6',
        default => '#e8f0fe',
    };
    $border = match($tipo) {
        'success' => '#27ae60',
        'warning' => '#f39c12',
        'danger' => '#c0392b',
        default => '#2b6be0',
    };
@endphp

<div style="background:{{ $bg }}; border-left:4px solid {{ $border }}; padding:12px; border-radius:6px; margin:12px 0">
    <strong style="color:#2d3748">{{ $mensaje }}</strong>
</div>
