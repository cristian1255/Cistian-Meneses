<h1 style="font-size:22px;color:#2c3e50;margin:14px 0;">
    {{ $slot }}
</h1>
