<div style="background:#fff;border-radius:8px;padding:14px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.06)">
    <h3 style="margin:0 0 8px 0;color:#1f8f4a">{{ $titulo }}</h3>

    <div>
        {{ $slot }}
    </div>

    <div style="margin-top:10px;color:#666;font-size:13px">
        {{-- $footer es un slot nombrado --}}
        {{ $footer ?? '' }}
    </div>
</div>
