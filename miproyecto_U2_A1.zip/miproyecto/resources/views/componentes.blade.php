<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Práctica Componentes - Razas de Ganado</title>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style>
        body{font-family: Arial, Helvetica, sans-serif; margin:20px; background:#f4f6f8;}
        header{height:220px;background:url('https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=1600&q=80') center/cover no-repeat; display:flex;align-items:center;justify-content:center;color:#fff;font-size:28px;text-shadow:2px 2px 6px rgba(0,0,0,.6);border-radius:6px}
        .container{display:flex;gap:20px;margin-top:20px}
        .left{width:260px;background:#2c3e50;color:#fff;padding:20px;border-radius:6px}
        .right{flex:1;padding:20px}
        .raza-card{background:#fff;padding:15px;border-radius:8px;box-shadow:0 2px 6px rgba(0,0,0,.08);margin-bottom:16px}
        .raza-card img{width:100%;height:180px;object-fit:cover;border-radius:6px}
    </style>
</head>
<body>

<header>Panel de Componentes - Razas de Ganado</header>

<div class="container">
    <div class="left">
        <h3>Menú</h3>
        <ul>
            <li><a href="{{ route('componentes') }}" style="color:#fff;text-decoration:none">Inicio</a></li>
            <li style="margin-top:8px;color:#ddd">Razas</li>
            <li style="margin-top:8px;color:#ddd">Alimentación</li>
        </ul>
    </div>

    <div class="right">
        {{-- Componente anónimo (slot simple) --}}
        <x-titulo>Práctica de Componentes en Laravel</x-titulo>

        {{-- Componente con clase (alerta) --}}
        <x-alerta tipo="success" mensaje="El proyecto está funcionando correctamente."/>

        <h2 style="color:#27ae60;margin-top:20px">Listado de Razas</h2>

        {{-- Recorremos datos enviados por el controlador --}}
        @foreach($razas as $raza)
            {{-- Componente card con slot: mostramos cada raza --}}
            <x-card titulo="{{ $raza['nombre'] }}">
                <img src="{{ $raza['imagen'] }}" alt="{{ $raza['nombre'] }}" style="width:100%;height:220px;object-fit:cover;border-radius:6px;margin-bottom:10px">
                <p>{{ $raza['descripcion'] }}</p>

                <x-slot name="footer">
                    ID: {{ $raza['id'] }} — Fuente: Pixabay
                </x-slot>
            </x-card>
        @endforeach

    </div>
</div>

</body>
</html>
