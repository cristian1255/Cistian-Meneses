<h1 style="font-size:22px;color:#2c3e50;margin:14px 0;">
    <?php echo e($slot); ?>

</h1>
<?php /**PATH /home/cristian/servidor/miproyecto/resources/views/components/titulo.blade.php ENDPATH**/ ?>