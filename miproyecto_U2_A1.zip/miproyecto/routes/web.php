<?php

use App\Http\Controllers\GanadoController;

Route::get('/componentes-ganado', [GanadoController::class, 'index'])
    ->name('componentes');
