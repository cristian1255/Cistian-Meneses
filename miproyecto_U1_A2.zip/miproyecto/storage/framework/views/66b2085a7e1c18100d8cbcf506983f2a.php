<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Control</title>
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body class="bg-gray-100 h-screen flex flex-col">

    <!-- HEADER -->
    <header class="h-48 bg-gray-300 flex items-center justify-center relative">
        <img src="<?php echo e(asset('images/header.jpg')); ?>" alt="Imagen de referencia"
             class="object-cover w-full h-full absolute top-0 left-0 opacity-70">
        <h1 class="text-2xl font-semibold text-white z-10 bg-black/50 px-4 py-2 rounded">
            Coloque una imagen para llenar este espacio y dar forma a la página
        </h1>
    </header>

    <!-- CONTENEDOR PRINCIPAL -->
    <div class="flex flex-1">

        <!-- SIDEBAR -->
        <aside class="w-60 bg-gray-200 p-4 space-y-2">
            <h2 class="text-blue-700 font-bold mb-4">Dashboard</h2>
            <nav class="space-y-2">
                <a href="#" class="block bg-blue-100 p-2 rounded hover:bg-blue-200">Posts</a>
                <a href="#" class="block bg-blue-100 p-2 rounded hover:bg-blue-200">Media</a>
                <a href="#" class="block bg-blue-100 p-2 rounded hover:bg-blue-200">Pages</a>
                <a href="#" class="block bg-blue-100 p-2 rounded hover:bg-blue-200">Comments</a>
                <a href="#" class="block bg-blue-100 p-2 rounded hover:bg-blue-200">Settings</a>
            </nav>

            <div class="mt-6 bg-yellow-200 p-3 rounded-lg shadow">
                <p class="text-sm">
                    Este es el menú, contemple 5 ítems que usted desee
                </p>
            </div>
        </aside>

        <!-- CONTENIDO -->
        <main class="flex-1 p-6 flex justify-center items-center">
            <div class="bg-yellow-200 p-4 rounded-lg shadow w-80 text-center">
                <p>
                    En el contenido puede ir texto aleatorio,<br>
                    únicamente es para demostrar que funciona,<br>
                    trate de poner algo relacionado con el ítem<br>
                    de menú seleccionado.
                </p>
            </div>
        </main>
    </div>

</body>
</html>
<?php /**PATH /home/cristian/servidor/miproyecto/resources/views/dashboard.blade.php ENDPATH**/ ?>