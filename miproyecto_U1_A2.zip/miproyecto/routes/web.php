<?php

//use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GanadoController;

Route::get('/ganado', [GanadoController::class, 'index'])->name('ganado.index');
