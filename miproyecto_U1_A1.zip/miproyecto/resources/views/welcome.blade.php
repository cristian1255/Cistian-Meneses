<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel Ganadero</title>
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            display: flex;
            flex-direction: column;
            height: 100vh;
            background-color: #ecf0f1;
        }

        header {
            background-image: url("/imagen/images.jpeg");            
            background-size: 100% auto; /* ¡Cambio aquí! */
            background-position: center;
            background-repeat: no-repeat; /* Recomendado con 'contain' para evitar mosaicos */
            height: 400px; /* <-- antes estaba en 220px */
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 5px 5px 8px rgba(0,0,0,0.6);
            border-bottom: 5px solid #27ae60;
        }

        main {
            display: flex;
            flex: 1;
        }

        nav {
            width: 240px;
            background-color: #2c3e50;
            color: white;
            padding: 20px;
        }

        nav h3 {
            margin-bottom: 20px;
            font-size: 1.2rem;
            text-transform: uppercase;
        }

        nav ul {
            list-style: none;
        }

        nav li {
            padding: 12px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            cursor: pointer;
            transition: background 0.2s;
        }

        nav li:hover {
            background-color: #34495e;
        }

        section {
            flex: 1;
            padding: 40px;
            overflow-y: auto;
        }

        h2 {
            color: #27ae60;
            margin-bottom: 20px;
        }

        p {
            margin-bottom: 15px;
            line-height: 1.6;
            text-align: justify;
        }

        ul.info-list {
            margin-left: 20px;
        }
    </style>
</head>
<body>

    <header>
        Panel de Información Ganadera
    </header>

    <main>
        <nav>
            <h3>Menú</h3>
            <ul>
                <li>Inicio</li>
                <li>Razas</li>
                <li>Alimentación</li>
                <li>Producción</li>
                <li>Contacto</li>
            </ul>
        </nav>

        <section>
            <h2>Razas de Ganado más Comunes</h2>
            <p>En la ganadería, existen distintas razas bovinas adaptadas a diferentes climas, usos y propósitos productivos. Algunas se especializan en la producción de carne, otras en leche y algunas son de doble propósito.</p>

            <h3>🐄 Razas de Carne</h3>
            <ul class="info-list">
                <li><b>Angus:</b> Originaria de Escocia, famosa por su carne marmoleada y suave textura.</li>
                <li><b>Hereford:</b> Resistente y de gran rusticidad, ideal para climas templados y fríos.</li>
                <li><b>Brahman:</b> Popular en climas cálidos y húmedos por su resistencia a parásitos.</li>
            </ul>

            <h3>🐮 Razas Lecheras</h3>
            <ul class="info-list">
                <li><b>Holstein:</b> La raza lechera más común del mundo, de gran producción diaria.</li>
                <li><b>Jersey:</b> Produce leche con alto contenido de grasa y proteína, ideal para quesos.</li>
                <li><b>Brown Swiss:</b> Muy longeva, combina buena producción con docilidad.</li>
            </ul>

            <h3>🌾 Alimentación del Ganado</h3>
            <p>La alimentación debe basarse en forraje verde, heno y suplementos minerales. En épocas secas, se utilizan silos o bloques nutricionales para mantener la salud y productividad del hato.</p>

            <h3>📈 Producción Sostenible</h3>
            <p>El manejo responsable del suelo, el agua y los desechos animales es esencial para reducir el impacto ambiental y mejorar la rentabilidad a largo plazo.</p>

            <h3>📞 Contacto</h3>
            <p>Para más información o asesoría técnica sobre manejo de razas y producción ganadera, comuníquese con su asociación local de productores o instituciones agropecuarias de su región.</p>
        </section>
    </main>

</body>
</html>
